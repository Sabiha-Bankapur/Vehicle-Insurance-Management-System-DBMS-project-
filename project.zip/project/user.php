<?php  
		$servername = "localhost";  
		$username = "root";  
		$password = "";  
		$conn = mysqli_connect($servername , $username , $password,"users") or die("unable to connect to host"); 
?>   