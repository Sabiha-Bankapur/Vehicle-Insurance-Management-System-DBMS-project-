<?php
include "connection.php";
$sql="select from policy p,claim c,payment pm where p.Policy_Num=c.Policy_Num and c.Claim_Num=pm.Claim_Num and 
case '$Claim_Date' between '$Policy_Issue_Date' and '$Policy_End_Date' then 
Amount_Paid=0.7*Bill_Amount else Amount_Paid=0";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_object($result);
?>