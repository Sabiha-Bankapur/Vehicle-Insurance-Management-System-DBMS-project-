<?php
		include "../connection.php";
		$pt=$_POST['Policy_Type'];
		$pid=$_POST['Policy_Issue_Date'];
		$ped=$_POST['Policy_End_Date'];
		$pp=$_POST['Policy_Premium'];
		$t=$_POST['Term'];
		$vno=$_POST['Vehicle_Num'];
		$cid=$_POST['Customer_Num'];
		$query="insert into policy(Policy_Type,Policy_Issue_Date,Policy_End_Date,Policy_Premium,Term,Vehicle_Num,Customer_Num) values('$pt','$pid','$ped',$pp,$t,'$vno',$cid)";
		mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>