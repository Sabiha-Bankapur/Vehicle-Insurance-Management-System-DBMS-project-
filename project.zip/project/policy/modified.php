<?php    
    
include "input.php";    
$sql = "select * from policy";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
		<link href = "../style.css" type = "text/css" rel = "stylesheet" />    
	   <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
	   <table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Policy Number</td> 
                <td>Policy Type</td>
                <td>Policy Issue Date</td>				
                <td>Policy End Date</td>
				<td>Policy Premium</td>
				<td>Term</td>
				<td>Vehicle Number</td>
				<td>Customer Number</td>    
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Policy_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Policy_Type;?>  
				</td>  
				<td>  
					<?php echo $row->Policy_Issue_Date;?>  
				</td>  
				<td>  
					<?php echo $row->Policy_End_Date;?>  
				</td>  
				<td>  
					<?php echo $row->Policy_Premium;?>  
				</td>  
				<td>  
					<?php echo $row->Term;?>  
				</td>  
				<td>  
					<?php echo $row->Vehicle_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Customer_Num;?>  
				</td>
				<td> <a href="delete.php?pn=<?php echo $row->Policy_Num;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> </td>    
			</tr>  
		<?php } ?>  			
        </table>   		
	<?php header('Location:modified1.php');?>
    </body>    
</html>