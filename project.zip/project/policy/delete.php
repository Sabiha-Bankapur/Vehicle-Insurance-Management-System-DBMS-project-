<?php
include "../connection.php";    
if(is_numeric($_GET['pn'])){    
$sql = "delete from policy where Policy_Num = '".$_GET['pn']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>