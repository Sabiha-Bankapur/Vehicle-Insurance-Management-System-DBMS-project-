<html>    
		<head>    
        <title>Policy Registration</title>    
    </head>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>

		</ul>
		<h2>Policy</h2>    
        <form name = "form1" action='modified.php' method = 'POST' enctype = "multipart/form-data" >    
            <div class = "container">
                <div class = "form_group">    
                    <label>Policy_Type:</label>    
                    <input type = "text" name = "Policy_Type" value = "" required />    
                </div>  
				<div class = "form_group">    
                    <label>Policy Issue Date:</label>    
                    <input type = "date" name = "Policy_Issue_Date" value = "" required />    
                </div>
				
				<div class = "form_group">    
                    <label>Policy End Date: </label>    
                    <input type = "date" name = "Policy_End_Date" value = ""  required />    
                </div>
				<div class = "form_group">    
                    <label>Policy Premium: </label>    
                    <input type = "text" name = "Policy_Premium" value = ""  required />    
                </div>
				<div class = "form_group">    
                    <label>Term: </label>    
                    <input type = "text" name = "Term" value = ""  required />    
                </div>
				<div class = "form_group">    
                    <label>Vehicle Number: </label>    
                    <select name = "Vehicle_Num">
					<?php 
						include "../connection.php";
						$sql="select * from vehicle";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Vehicle_Num?>"><?php echo $row->Vehicle_Num?></option>
						<?php } ?>
						</select>
				</div>
				<div class = "form_group">    
                    <label>Customer Number:</label>    
                    <select name = "Customer_Num">
					<?php 
						include "../connection.php";
						$sql="select * from customer";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Customer_Num?>"><?php echo $row->Customer_Num?></option>
						<?php } ?>
						</select>
                </div>          
				<div class = "form_group">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group">    
                    <input type = "reset" value = "reset"/>    
                </div>
				
            </div>    
        </form>    
    </body>    
</html>    