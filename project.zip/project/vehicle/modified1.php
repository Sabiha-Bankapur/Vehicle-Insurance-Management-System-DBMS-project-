<?php    
    
include "../connection.php";        
$sql = "select * from vehicle";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h1><center>Vehicle Data</center></h1>
		
		<table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Vehicle Number</td>    
                <td>Vehicle Company</td>    
                <td>Vehicle Model</td>        
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Vehicle_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Vehicle_Company;?>  
				</td>  
				<td>  
					<?php echo $row->Vehicle_Model;?>  
				</td>   
				<td> <a href="delete.php?vno=<?php echo $row->Vehicle_Num;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> </td>  
			</tr>  
		<?php } ?>  			
        </table>   		
    </body>    
</html>