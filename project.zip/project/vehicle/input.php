<?php
		include "../connection.php";
		$vno=$_POST['Vehicle_Num'];
		$vc=$_POST['Vehicle_Company'];
		$vm=$_POST['Vehicle_Model'];
		$query="insert into vehicle(Vehicle_Num,Vehicle_Company,Vehicle_Model) values('$vno','$vc','$vm')";
		mysqli_query($conn,$query) or die($query."can't connect to query");
?>