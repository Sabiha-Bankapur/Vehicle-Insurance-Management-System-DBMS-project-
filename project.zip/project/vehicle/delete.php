<?php
include "../connection.php";    
if(ctype_alnum($_GET['vno'])){    
$sql = "delete from vehicle where Vehicle_Num = '".$_GET['vno']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>
