<?php
		include "../connection.php";
		$vno=$_GET['Vehicle_Num'];
		$vc=$_GET['Vehicle_Company'];
		$vm=$_GET['Vehicle_Model'];
		$query="insert into vehicle values('$vno','$vc','$vm')";
		mysqli_query($conn,$query) or die($query."can't connect to query");
?>