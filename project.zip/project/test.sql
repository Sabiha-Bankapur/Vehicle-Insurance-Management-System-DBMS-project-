-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2018 at 10:52 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------
create table `vehicle`(
  `Vehicle_Num` varchar(50) not null, 
  `Vehicle_Company` varchar(50) not null,
  `Vehicle_Model` varchar(50) not null
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `vehicle`(`Vehicle_Num`,`Vehicle_Company`,`Vehicle_Model`) values ( 'ka25n197', 'tata','nexon');

CREATE TABLE `customer` (
  `Customer_Num` bigint(10) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Middle_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Gender` char(1) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(70) NOT NULL,
  `Contact_Number` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `customer` (`Customer_Num`, `First_Name`, `Middle_Name`, `Last_Name`, `Gender`, `DOB`, `Address`, `Contact_Number`) VALUES
(100, 'Sonal', 'M', 'Patel', 'F', '2000-10-10', 'Hubli', 9611565567);

CREATE TABLE `policy` (
  `Policy_Num` bigint(10) NOT NULL,
  `Policy_Type` varchar(50) NOT NULL,
  `Policy_Issue_Date` date NOT NULL,
  `Policy_End_Date` date NOT NULL,
  `Policy_Premium` bigint(50) NOT NULL,
  `Term` int(2) NOT NULL,
  `Vehicle_Num` varchar(50) NOT NULL,
  `Customer_Num` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `policy` (`Policy_Num`, `Policy_Type`, `Policy_Issue_Date`, `Policy_End_Date`, `Policy_Premium`, `Term`, `Vehicle_Num`, `Customer_Num`) VALUES
(1000, 'comprehensive', '2017-10-02', '2018-10-02', 4000, 1,'ka25n197' , 100);



create table `bill` (
 `Bill_Num` varchar(50) not null,
 `Bill_Amount` bigint(10) not null,
 `Customer_Num` bigint(10) not null
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `bill` (`Bill_Num`,`Bill_Amount`,`Customer_Num`) values ('3s3s3',10000,100);

create table `claim` (
 `Claim_Num` varchar(20) not null,
 `Claim_Type` varchar(50) not null,
 `Claim_Date` date not null,
 `Bill_Num` varchar(50) not null,
 `Policy_Num` bigint(10) not null
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `claim` (`Claim_Num`,`Claim_Type`,`Claim_Date`,`Bill_Num`,`Policy_Num`) values ('3000we','accident','2017-10-10','3s3s3',1000);

create table `payment` (
 `Payment_Num` bigint(10) not null,
 `Payment_Type` varchar(50) not null,
 `Payment_Date` date not null,
 `Claim_Num` varchar(20) not null,
 `Amount_Paid` bigint(10) null
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `payment` (`Payment_Num`,`Payment_Type`,`Payment_Date`,`Claim_Num`,`Amount_Paid`) values (4000,'cheque','2017-10-20','3000we','');

alter table `vehicle` 
add primary key (`Vehicle_Num`);

ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_Num`);

ALTER TABLE `policy`
  ADD PRIMARY KEY (`Policy_Num`),
  ADD KEY `Vehicle_Num` (`Vehicle_Num`),
  ADD KEY `Customer_Num` (`Customer_Num`);


alter table `bill`
  add primary key (`Bill_Num`),
  add key `Customer_Num` (`Customer_Num`);

alter table `claim`
  add primary key (`Claim_Num`),
  add key `Bill_Num` (`Bill_Num`),
  add key `Policy_Num` (`Policy_Num`);

  
alter table `payment`
  add primary key (`Payment_Num`),
  add key `Claim_Num`(`Claim_Num`);

ALTER TABLE `customer`
  MODIFY `Customer_Num` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

ALTER TABLE `policy`
  ADD CONSTRAINT `Vehicle_Num` FOREIGN KEY (`Vehicle_Num`) REFERENCES `vehicle` (`Vehicle_Num`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Customer_Num` FOREIGN KEY (`Customer_Num`) REFERENCES `customer` (`Customer_Num`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `policy`
  MODIFY `Policy_Num` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;


alter table `bill`
  add constraint `Customer_Num` foreign key (`Customer_Num`) references `customer` (`Customer_Num`) on delete cascade on update cascade;

alter table `claim`
  add constraint `Bill_Num` foreign key (`Bill_Num`) references `bill` (`Bill_Num`) on delete cascade on update cascade,
  add constraint `Policy_Num` foreign key (`Policy_Num`) references `policy` (`Policy_Num`) on delete cascade on update cascade;
  
     
alter table `payment` 
   add constraint `Claim_Num` foreign key (`Claim_Num`) references `claim` (`Claim_Num`) on delete cascade on update cascade;
   
alter table `payment`
   modify `Payment_Num` bigint(10) not null auto_increment, auto_increment=4001;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
