<?php
session_start();
include 'user.php';
$uname = $_POST['uname'];
$psw = $_POST['psw'];
$sql = "select * from list where Username='$uname' and Password='$psw'";
$result = mysqli_query($conn, $sql);
$rowcount = $result->num_rows;
if($rowcount==1)
 header("Location: index.php");
else
 echo "Wrong Username/Password. Try Again.";
?>