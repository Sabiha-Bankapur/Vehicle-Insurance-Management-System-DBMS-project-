<?php    
    
include "input.php";    
$sql = "select * from bill";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <link href = "../style.css" type = "text/css" rel = "stylesheet" />    
		<link href = "registration.css" type = "text/css" rel = "stylesheet" />    
		<table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Bill Number</td>    
                <td>Bill Amount</td>    
                <td>Customer Number</td>      
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Bill_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Bill_Amount;?>  
				</td>  
				<td>  
					<?php echo $row->Customer_Num;?>  
				</td>    
				<td> <a href="delete.php?bno=<?php echo $row->Bill_Num;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> </td>  
			</tr>  
		<?php } ?>  			
        </table>   		
	<?php header('Location:modified1.php');?>
    </body>    
</html>