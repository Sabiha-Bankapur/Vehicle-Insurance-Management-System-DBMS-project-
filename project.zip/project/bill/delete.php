<?php
include "../connection.php";    
if(ctype_alnum($_GET['bno'])){    
$sql = "delete from bill where bill_Num = '".$_GET['bno']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>
				