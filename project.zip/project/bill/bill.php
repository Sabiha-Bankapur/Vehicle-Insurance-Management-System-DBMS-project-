<html>    
    <head>    
        <title>bill registration</title>    
    </head>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h2>Bill</h2>    
        <form name = "form1" action='modified.php' method = 'POST' enctype = "multipart/form-data" >    
            
		<div class = "container">
		<div class = "form_group">
				    <label>Bill Number:</label>
					<input type = "text" name = "Bill_Num" value = "" required />
				</div>

				<div class = "form_group">
				    <label>Bill Amount:</label>
					<input type = "text" name = "Bill_Amount" value = "" required />
				</div>
				<div class = "form_group">
				    <label>Customer Number:</label>
					<select name = "Customer_Num">
					<?php 
						include "../connection.php";
						$sql="select * from customer";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Customer_Num?>"><?php echo $row->Customer_Num?></option>
						<?php } ?>
						</select>
				</div>
				<div class = "form_group">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group">    
                    <input type = "reset" value = "reset"/>    
                </div>
			</div>
		</form>
	</body>
</html>