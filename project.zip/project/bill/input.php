<?php
		include "../connection.php";
		$bno=$_POST['Bill_Num'];
		$ba=$_POST['Bill_Amount'];
		$cid=$_POST['Customer_Num'];
		$query="insert into bill(Bill_Num,Bill_Amount,Customer_Num) values('$bno','$ba','$cid')";
		mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>