<?php
    include "../connection.php";
	$fn=$_POST['First_Name'];
	$mn=$_POST['Middle_Name'];
	$d=$_POST['DOB'];
	$ln=$_POST['Last_Name'];
	$g=$_POST['Gender'];
	$a=$_POST['Address'];
	$con=$_POST['Contact_Number'];
	$query="insert into customer(First_Name,Middle_Name,Last_Name,Gender,DOB,Address,Contact_Number) values ('$fn','$mn','$ln','$g','$d','$a',$con)";
	mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>