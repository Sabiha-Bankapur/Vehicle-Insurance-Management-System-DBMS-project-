<?php
include "../connection.php";    
if(is_numeric($_GET['cid'])){    
$sql = "delete from customer where Customer_Num = '".$_GET['cid']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>