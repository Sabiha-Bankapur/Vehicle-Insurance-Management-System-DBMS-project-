<?php
include "../connection.php";    
if(ctype_alnum($_GET['cno'])){    
$sql = "delete from claim where Claim_Num = '".$_GET['cno']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>
