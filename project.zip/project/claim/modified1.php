<?php    
    
include "../connection.php";        
$sql = "select * from claim";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h1><center>Claim Data</center></h1>
		
		<table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Claim Number</td>    
                <td>Claim Type</td>    
                <td>Claim Date</td>    
                <td>Bill Number</td>
				<td>Policy Number</td>				
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Claim_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Claim_Type;?>  
				</td>  
				<td>  
					<?php echo $row->Claim_Date;?>  
				</td>   
				<td>
				    <?php echo $row->Bill_Num;?>
			    </td>
				<td>
				    <?php echo $row->Policy_Num;?>
			    </td>

				<td> <a href="delete.php?cno=<?php echo $row->Claim_Num;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> </td>  
			</tr>  
		<?php } ?>  			
        </table>   		
    </body>    
</html>