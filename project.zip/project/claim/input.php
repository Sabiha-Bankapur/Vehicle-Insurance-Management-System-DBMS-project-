<?php
		include "../connection.php";
		$cno=$_POST['Claim_Num'];
		$ct=$_POST['Claim_Type'];
		$cd=$_POST['Claim_Date'];
		$bno=$_POST['Bill_Num'];
		$pn=$_POST['Policy_Num'];
		$query="insert into claim(Claim_Num,Claim_Type,Claim_Date,Bill_Num,Policy_Num) values('$cno','$ct','$cd','$bno',$pn)";
		mysqli_query($conn,$query) or die($query."can't connect to query");
?>