<html>    
    <head>    
        <title>claim registration</title>    
    </head>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h2>Claim</h2>    
        <form name = "form1" action='modified.php' method = 'POST' enctype = "multipart/form-data" >  

		<div class = "container">
             
                <div class = "form_group">    
                    <label>Claim Number:</label>    
                    <input type = "text" name = "Claim_Num" value = "" required />    
                </div>    
				<div class = "form_group">
				    <label>Claim Type:</label>
					<input type = "text" name = "Claim_Type" value = "" required />
				</div>
				<div class = "form_group">
				    <label>Claim Date:</label>
					<input type = "date" name = "Claim_Date" value = ""required />
				</div>
				<div class = "form_group">    
                    <label>Bill Number: </label>    
                    <select name = "Bill_Num">
					<?php 
						include "../connection.php";
						$sql="select * from bill";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Bill_Num?>"><?php echo $row->Bill_Num?></option>
						<?php } ?>
						</select>
				</div>


				<div class = "form_group">    
                    <label>Policy Number: </label>    
                    <select name = "Policy_Num">
					<?php 
						include "../connection.php";
						$sql="select * from policy";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Policy_Num?>"><?php echo $row->Policy_Num?></option>
						<?php } ?>
						</select>
				</div>




				<div class = "form_group">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group">    
                    <input type = "reset" value = "reset"/>    
                </div>
			</div>
		</form>
	</body>
</html>