<html>
<head>
    <title>Admin Login Page</title>
    <link rel = "stylesheet" type="text/css" href="Form.css">
</head>
<body>
    <h1>LOGIN</h1>
      <form action="login2.php" method="post">
       <table>
        <tr>
         <td>Username :</td> <td><input type="text" name="usrname"></td><br>
        </tr>
        <tr>
         <td>Password :</td> <td><input type="password" name="pwd"></td><br>
        </tr>
        
        <input type="submit" value="Submit" onclick="nextpage()">

           
         
         
       </table>
      </form>
</body>
</html>

<script>
        function nextpage(){
            header("Location:index.php");
        
        }
        </script>