<html>
<head>
<title>
vehicle insurance
</title>
</head>
<body>
<link href = "registration.css" type = "text/css" rel = "stylesheet" />  
<link href = "style.css" type = "text/css" rel = "stylesheet" />  
<div class="title">
<h1><center>Vehicle Insurance Management System</center></h1>
</div>
<div class="links">
</div>
<nav> 

<ul style="position:fixed;width:50%;top:10%;right:50%;left:0%;">
	<li><a href="vehicle/vehicle.php"><h3>vehicle registration</h3></a></li>
	<li><a href="customer/customer.php"> <h3>customer registration</h3></a></li>
	<li><a href="policy/policy.php"> <h3>policy registration</h3></a></li>
	<li><a href="bill/bill.php"><h3>bill registration</h3></a></li>
	<li><a href="claim/claim.php"><h3>claim Registration</h3></a><li>
	<li><a href="payment/payment.php"><h3>payment registration</h3></a></li>
</ul>

</nav> 
<nav>
<ul style="position:fixed;top:10%;width:50%;right:0%;left:50%;">
	<li><a href="vehicle/modified1.php"><h3>vehicle data</h3></a></li>
	<li><a href="customer/modified1.php"><h3>customer Data</h3></a></li>
	<li><a href="policy/modified1.php"><h3>policy Data</h3></a></li>
	<li><a href="bill/modified1.php"><h3>bill Data</h3></a></li>
	<li><a href="claim/modified1.php"><h3>claim Data</h3></a></li>
	<li><a href="payment/modified1.php"><h3>payment Data</h3></a></li>
</ul>
</nav>
</body>
</html>