<html>
<head>
    <title>Admin Login Page</title>
    <link rel = "stylesheet" type="text/css" href="Form.css">
</head>
<body>

<table style="margin-left:auto;margin-right:auto">

<tr style="text-align:center">
      <td colspan="2">
        <h2> National Insurance Company <br>We provide confidence behind your wheels</h2>
      </td>
      </tr>


<tr>
<td valign="top">
    <h1>LOGIN</h1>
      <form action="login2.php" method="post">
       
        <label for="uname"><b>Username:</b></label><br>
        <input type="text" name="uname" required><br>
        
        <label for="uname"><b>Password:</b></label><br>
        <input type="password" name="psw" required><br>
    
        
        <input type="submit" name = "submit" value="Submit">
      </form>
      </td>
      <td>
        <img src="insurance.jpg" width="90%" height="90%" />
      </td>
      </tr>

      </table>

</body>
</html>
