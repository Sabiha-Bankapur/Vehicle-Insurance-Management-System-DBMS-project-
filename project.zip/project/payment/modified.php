<html>    
    <body>    
        <link href = "../style.css" type = "text/css" rel = "stylesheet" />    
		<link href = "registration.css" type = "text/css" rel = "stylesheet" />    
	<?php  

//query
include "input.php";    

$sql = "select * from claim where Claim_Num = '$cno'";

$result = mysqli_query($conn,$sql);    

if($row = mysqli_fetch_object($result))
{
	$Claim_Date = $row->Claim_Date;
	$Policy_Num = $row->Policy_Num;
	$Bill_Num = $row->Bill_Num;

	$sql1 = "select * from policy where Policy_Num = $Policy_Num and Policy_Issue_Date <= '$Claim_Date' and Policy_End_Date >= '$Claim_Date'";
	$result1 = mysqli_query($conn,$sql1);    

	if($row1 = mysqli_fetch_object($result1))
	{
		echo "Valid Claim,";
		$sql2 = "select * from bill where Bill_Num = '$Bill_Num'";
		$result2 = mysqli_query($conn,$sql2);    

		if($row2 = mysqli_fetch_object($result2))
		{
			$Bill_Amount = $row2->Bill_Amount;

			$Amount_Paid = 0.7 * $Bill_Amount;

			$query = "insert into payment(Payment_Type, Payment_Date, Claim_Num, Amount_Paid) values('$pt','$pd','$cno',$Amount_Paid)";
			mysqli_query($conn,$query) or die($query."can't connect to query");

			echo "Payment made successfully.";

		}
	}
	else
	{
		echo " Invalid Claim. Policy expired";
	}
}
    
	?>  


    </body>    
</html>