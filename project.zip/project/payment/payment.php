<html>    
    <head>    
        <title>payment registration</title>    
    </head>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h2>Payment</h2>    
        <form name = "form1" action='modified.php' method = 'POST' enctype = "multipart/form-data" >    
            <div class = "container">
                
				<div class = "form_group">
				    <label>Payment Type:</label>
					<input type = "text" name = "Payment_Type" value = "" required />
				</div>
				<div class = "form_group">
				    <label>Payment Date:</label>
					<input type = "date" name = "Payment_Date" value = ""required />
				</div>
				<div class = "form_group">    
                    <label>Claim Number: </label>    
                    <select name = "Claim_Num">
					<?php 
						include "../connection.php";
						$sql="select * from claim";
						$result = mysqli_query($conn,$sql);
						$i=0;
						while($row=mysqli_fetch_object($result)){
							$i++;
					?>
						<option value = "<?php echo $row->Claim_Num?>"><?php echo $row->Claim_Num?></option>
						<?php } ?>
						</select>
				</div>
				     
				<div class = "form_group">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group">    
                    <input type = "reset" value = "reset"/>    
                </div>
			</div>
		</form>
	</body>
</html>