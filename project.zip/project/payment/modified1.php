<?php    
    
include "../connection.php";        
$sql = "select * from payment";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <link href = "registration.css" type = "text/css" rel = "stylesheet" /> 
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 	
		<ul>
			<li style="float:right;"><a href="../index.php"> Back to homepage</a></li>
		</ul>
		<h1><center>Payment Data</center></h1>
		
		<table width = "100%" border = "1" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Payment Number</td>    
                <td>Payment Type</td>    
                <td>Payment Date</td>    
                <td>Claim Number</td>
                <td>Amount Paid</td>				
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Payment_Num;?>  
				</td>  
				<td>  
					<?php echo $row->Payment_Type;?>  
				</td>  
				<td>  
					<?php echo $row->Payment_Date;?>  
				</td>   
				<td>
				    <?php echo $row->Claim_Num;?>
			    </td>
				<td>
				    <?php echo $row->Amount_Paid;?>
				</td>>

				<td> <a href="delete.php?pid=<?php echo $row->Payment_Num;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> </td>  
			</tr>  
		<?php } ?>  			
        </table>   		
    </body>    
</html>