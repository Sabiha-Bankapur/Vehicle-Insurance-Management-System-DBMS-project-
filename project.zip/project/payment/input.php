<?php
		include "../connection.php";
		$pt=$_POST['Payment_Type'];
		$pd=$_POST['Payment_Date'];
		$cno=$_POST['Claim_Num'];
		//$query="insert into payment(Payment_Num,Payment_Type,Payment_Date,Claim_Num,Amount_Paid) values('$pt','$pd','$cno',$ap)";
		//mysqli_query($conn,$query) or die($query."can't connect to query");
?>