<?php
include "../connection.php";    
if(is_numeric($_GET['pid'])){    
$sql = "delete from payment where Payment_Num = '".$_GET['pid']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:modified1.php');
?>
